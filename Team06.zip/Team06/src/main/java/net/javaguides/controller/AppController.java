package net.javaguides.controller;

import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import net.javaguides.model.User;

@Controller
public class AppController  {

	@RequestMapping(value = {"/", "/index" , "/home"})
	public String homePage() {
		return "index";
	}
	
	@GetMapping("/signUp")
	  public String registPage(Model model) {
		model.addAttribute("user", new User());
		
		return "signUp";
	}
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	@GetMapping(value = "/logout")
	public String logout_user(HttpSession session) {
		session.removeAttribute("username");
		session.removeAttribute("error");
		session.invalidate();
		return "redirect:/";
	}
	
	@GetMapping(value = "/hello")
	  public String hello(Model model) {
		model.addAttribute("user", new User());
		
		return "hello";
	}
	

}
