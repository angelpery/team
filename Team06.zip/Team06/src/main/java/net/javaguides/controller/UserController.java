package net.javaguides.controller;

import java.util.Collection;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.model.User;
import net.javaguides.repository.UserRepository;

@RestController
public class UserController {
	
	private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

	@Autowired UserRepository userRep;

	@Component
	class Users implements CommandLineRunner {
		@Override
		public void run(String... args) throws Exception {
			System.out.println("Available Users:");
			for (User u : userRep.findAll()) 
				System.out.println(u.getUsername());
		}
	}
	
	@PostMapping("/newuser")
	public String regist(User user) {
		String enPassword = encoder.encode(user.getPassword());
		user.setPassword(enPassword);
		userRep.save(user);
		
		return "register_success";
	}
	
	@RequestMapping("/users")
	Collection<User> users(){
		return userRep.findAll();
	}
	
	@PostMapping("/user")
	public String login_user(@RequestParam("username") String username, @RequestParam("password") String password,
			HttpSession session, ModelMap modelMap, Model model) {
		
		User auser = userRep.findByUsername(username);

		boolean login = this.getLoggedinUser(auser, username, password);
		System.out.print("aa");
		if(login) {
			model.addAttribute("username", username);
			session.setAttribute("username", username);
			session.setAttribute("loginPage", true);
			session.removeAttribute("error");
			System.out.println(username + " login.");
			return "redirect:/hello";
		}
		else {
			session.setAttribute("error", "Invalid username or password.");
			modelMap.put("error", "Invalid username or password.");
			return "redirect:/index";
		}
	}
	
	
	public boolean getLoggedinUser(User user, String userame, String password) {
	    
	    User userWithUsername = userRep.findByUsername(userame);
	
	    String hashedPassword = "";
	
	    if(userWithUsername != null) {
	    	hashedPassword = userWithUsername.getPassword();
	    }
	     
	    boolean isPasswordMatched = encoder.matches(password, hashedPassword);

        if(((userWithUsername != null) && isPasswordMatched)) {   
	        return true;
	    }
     
	   return false;
	}
	
}

