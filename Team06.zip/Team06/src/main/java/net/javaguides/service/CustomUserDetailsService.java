package net.javaguides.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import net.javaguides.config.CustomUserDetails;
import net.javaguides.model.User;
import net.javaguides.repository.UserRepository;

public class CustomUserDetailsService implements UserDetailsService {

	@Autowired 
	UserRepository userRep;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userRep.findByUsername(username);
		if( user == null) {
			throw new UsernameNotFoundException("User not found.");
		}
		return new CustomUserDetails(user);
	}

	//public User saveUser(User user) {
	//	User newUser = new User();
	//	newUser.setUsername(user.getUsername());
	//	newUser.getMovies()
	//		.add()
	//		.
	//}
}
