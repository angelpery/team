package net.javaguides.model;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "users")
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false, unique = true, length = 45)
	private String email;

	@Column(nullable = false, unique = true, length = 45)
	private String username;

	@Column(nullable = false, length = 64)
	private String password;

	@Column(columnDefinition="tinyint(1) default 0")
	private Integer failed_attempt = 0;

	@Column(columnDefinition="tinyint(1) default 1")
	private Integer account_non_locked = 1;
	
	@Column()
	private Timestamp lock_time;
	
		
	public Integer getFailed_attempt() {
		return failed_attempt;
	}

	public void setFailed_attempt(Integer failed_attempt) {
		this.failed_attempt = failed_attempt;
	}

	public Integer getAccount_non_locked() {
		return account_non_locked;
	}

	public void setAccount_non_locked(Integer account_non_locked) {
		this.account_non_locked = account_non_locked;
	}

	public Timestamp getLock_time() {
		return lock_time;
	}

	public void setLock_time(Timestamp lock_time) {
		this.lock_time = lock_time;
	}

	public User (String email, String username, String password) {
		this.email = email;
		this.username = username;
		this.password = password;
	}
	
	public User() {}
		
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
