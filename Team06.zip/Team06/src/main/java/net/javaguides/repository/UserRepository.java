package net.javaguides.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import net.javaguides.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
	
	@Query("from User where username=?1")
	User findByUsername(String username);
	
	@Query("from User where email=?1")
	User findByEmail(String email);

}
