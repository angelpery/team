package net.javaguides;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import net.javaguides.model.User;
import net.javaguides.repository.UserRepository;

@Configuration
class LoadDatabase {

	BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
	
	//create 3 users
	@Bean
	CommandLineRunner initDatabase(UserRepository userRepo) {
		return args -> {
			User angel = new User("aperisinaki@aueb.gr", "angel",  encoder.encode("1234"));
			User jim = new User("dtsopelas@aueb.gr", "jim", encoder.encode("1234"));
			User admin = new User("admin", "admin", encoder.encode("admin"));
      	
			userRepo.save(angel);
			userRepo.save(jim);
			userRepo.save(admin);
		};
	}

}